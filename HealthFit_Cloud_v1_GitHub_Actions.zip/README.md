# HealthFit — Cloud Build v1

Primeira versão mínima do aplicativo Android.

## Build na nuvem

O GitHub Actions compila o APK sem depender do AndroidIDE.

Workflow:
`.github/workflows/android-apk.yml`

Após o build, o arquivo `app-debug.apk` fica disponível em **Actions → workflow → Artifacts**.

## Próximas etapas

1. Dashboard mobile
2. Health Connect / Samsung Health
3. Peso e medidas
4. Importação de exames PDF
5. IA para cruzamento dos dados
