package com.healthfit.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView tv(String text, float size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(Color.rgb(25, 35, 45));
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        v.setPadding(0, 8, 0, 8);
        return v;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 24);
        root.setBackgroundColor(Color.rgb(248, 250, 252));

        TextView title = tv("HealthFit", 30, true);
        title.setTextColor(Color.rgb(13, 71, 161));
        root.addView(title);

        root.addView(tv("Seu painel de saúde e atividades", 16, false));

        root.addView(tv("\nResumo de hoje", 22, true));
        root.addView(tv("🏃 Atividades: 0\n🔥 Calorias: --\n⏱ Tempo ativo: --", 17, false));

        root.addView(tv("\nÚltimas atividades", 22, true));
        root.addView(tv("Nenhuma atividade importada ainda.\nNa próxima etapa conectaremos ao Health Connect / Samsung Health.", 16, false));

        root.addView(tv("\nSemana de treinos", 22, true));
        root.addView(tv("SEG   TER   QUA   QUI   SEX   SÁB   DOM\n—      —      —      —      —      —      —", 15, false));

        root.addView(tv("\nPróximas etapas", 22, true));
        root.addView(tv("• Conectar atividades físicas\n• Peso e medidas\n• Importar exames PDF\n• Análise inteligente dos dados", 16, false));

        setContentView(root);
    }
}
